# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['glossary']

package_data = \
{'': ['*'], 'glossary': ['.github/workflows/*']}

install_requires = \
['pyyaml>=5.3.1,<6.0.0', 'textdistance>=4.2.0,<5.0.0']

setup_kwargs = {
    'name': 'glossary',
    'version': '0.2',
    'description': 'Python package to define technical terms',
    'long_description': None,
    'author': 'ian-flores',
    'author_email': 'iflores.siaca@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
